# Selamat Datang di LNX#.CREW GitHub Blog
Disini hanya sepintas deskripsi singkat yang ingin kami sampaikan pada README.MD ,kami adalah sebuah Team yang berawal dari Underground bisa disebut mengikuti Alur Blackhat yang berpindah menuju Alur Whitehat. berfokus pada Bug Hunting dan Penetration Testing membuat kami bersemangat membuat Program-program dan tools yang bermanfaat untuk dipakai oleh semua orang. dan kami juga berterimakasih banyak kepada teman-teman yang telah ingin berjuang kepada kami dan teman-teman yang mengenal baik akan kami, Salam Open Source.

**_Keep Support Us!_**

**Program Populer**
- PTF (Pentest Tools Framework)
- Nuubi Tools
- ProxDownloader
- XRCross (Recon)
- CVE-2020-7246
- DDOS Crewz
> Lihat Alat/Program di Repositori GitHub kami dan Gunakan Semua

### Pratinjau Halaman

Masih Pengembangan
|--|
![img](https://raw.githubusercontent.com/lnxcrew/lnxcrew.github.io/master/Screenshot/Screenshot_1.png)

**Kunjungi GitHub Blogs**
- [Webpages](https://lnxcrew.github.io/)

> © 2020 LNX#.CREW
